from django.contrib import admin
from .models import Logo, Slider, DiscountProduct, Product, Services,Showcase, Contact

# Register your models here.
admin.site.register(Logo)
admin.site.register(Slider)
admin.site.register(DiscountProduct)
admin.site.register(Product)
admin.site.register(Services)
admin.site.register(Showcase)
admin.site.register(Contact)
