from django.db import models


# Create your models here.
class Logo(models.Model):
    logo = models.ImageField()


class Slider(models.Model):
    slider_1 = models.ImageField()
    slider_2 = models.ImageField()
    slider_3 = models.ImageField()


class DiscountProduct(models.Model):
    product_1 = models.ImageField()
    product_2 = models.ImageField()


class Product(models.Model):
    prod_1 = models.ImageField()
    prod_2 = models.ImageField()
    prod_3 = models.ImageField()


class Services(models.Model):
    service = models.ImageField()


class Showcase(models.Model):
    showcase_1 = models.ImageField()
    showcase_2 = models.ImageField()


class Contact(models.Model):
    # def __init__(self, *args, **kwargs):
    #     super().__init__(args, kwargs)
    #     self.is_valid = None

    name = models.CharField(max_length=255, blank=True, null=True)
    email = models.EmailField(max_length=254)
    message = models.TextField()


