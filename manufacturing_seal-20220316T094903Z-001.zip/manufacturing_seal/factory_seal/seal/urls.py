from django.urls import path

from seal import views

urlpatterns = [

    path('', views.listview, name='main-view'),
]
