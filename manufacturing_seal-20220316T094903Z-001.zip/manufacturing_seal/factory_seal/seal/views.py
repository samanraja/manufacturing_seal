from django.conf.global_settings import MEDIA_URL
from django.shortcuts import render, redirect
from urllib import request
from .models import Logo, Slider, DiscountProduct, Product, Services, Showcase, Contact
from django.conf import settings
from django.core.mail import send_mail


def listview(request):
    logo = Logo.objects.all().last()
    slider = Slider.objects.all().last()
    discount_product = DiscountProduct.objects.all().last()
    product = Product.objects.all().last()
    service = Services.objects.all().last()
    showcase = Showcase.objects.all().last()
    contact = Contact.objects.all().last()
    logo_image_path = logo.logo
    slider_1 = slider.slider_1
    slider_2 = slider.slider_2
    slider_3 = slider.slider_3
    discount_product_1 = discount_product.product_1
    discount_product_2 = discount_product.product_2
    prod_1 = product.prod_1
    prod_2 = product.prod_2
    prod_3 = product.prod_3
    service = service.service
    showcase_1 = showcase.showcase_1
    showcase_2 = showcase.showcase_2
    if request.method == "POST":
        form = Contact()
        if form:
            form.name = request.POST.get('name', None)
            form.email = request.POST.get('email', None)
            form.message = request.POST.get('message', None)
            subject = 'NEW CUSTOMER'
            message = f'{form.name} {form.name} {form.name}'
            email_from = settings.EMAIL_HOST_USER
            recipient_list = ['awesumminam@gmail.com']
            send_mail(subject, message, email_from,recipient_list)
            form.save()
    else:
        print("form is not valid")
    # email_from = settings.EMAIL_HOST_USER
    # recipient_list = [user.email, ]
    # send_mail(subject, message, email_from, recipient_list)
    context = {
        'logo_image_path': logo_image_path,
        'slider_1': slider_1,
        'slider_2': slider_2,
        'slider_3': slider_3,
        'discount_product_1': discount_product_1,
        'discount_product_2': discount_product_2,
        'prod_1': prod_1,
        'prod_2': prod_2,
        'prod_3': prod_3,
        'service': service,
        'showcase_1': showcase_1,
        'showcase_2': showcase_2,

    }
    return render(request, 'seal/index.html', {'context': context})
